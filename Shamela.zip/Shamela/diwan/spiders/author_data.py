import scrapy

class PoemSpider(scrapy.Spider):
    name = 'author_data'
    start_urls = [f'https://old.shamela.ws/index.php/author/{i}' for i in range(1, 3170)]

    def parse(self, response):
        xpath_death_date = '//div[@id="content"]//tr//td[contains(text(), "تاريخ الوفاة")]/../td[2]//text()'
        death_date = response.xpath(xpath_death_date).getall()

        xpath_author = '//div[@id="content"]//h3//text()'
        author = response.xpath(xpath_author).getall()

        xpath_author_full_name = '//div[@id="content"]//tr//td[contains(text(), "اسم المصنف")]/../td[2]//text()'
        author_full_name = response.xpath(xpath_author_full_name).getall()

        xpath_books = '//div[@id="content"]//tr//td[contains(text(), "كتب المصنف بالموقع")]/../td[2]//text()'
        books = response.xpath(xpath_books).getall()

        xpath_books_url = '//div[@id="content"]//tr//td[contains(text(), "كتب المصنف بالموقع")]/../td[2]//@href'
        books_url = response.xpath(xpath_books_url).getall()

        xpath_bio = '//div[@id="content"]//tr//td[contains(text(), "ترجمة المصنف")]/../td[2]//text()'
        bio = response.xpath(xpath_bio).getall()

        author_url_page = response.url

        xpath_book_puls_url = '//div[@id="content"]//tr//td[contains(text(), "كتب المصنف بالموقع")]/../td//a'
        book_puls_url = response.xpath(xpath_book_puls_url).getall()


        yield {
            'AUTHOR' : author,
            'AUTHOR_FULL_NAME': author_full_name,
            'DEATH_DATE' : death_date,
            'BOOKS': books,
            'BOOKS_URL': books_url, 
            'BIO'  : bio,
            'AUTHOR_PAGE': author_url_page,
            'BOOK_URL_DBL_CHECK': book_puls_url
        }