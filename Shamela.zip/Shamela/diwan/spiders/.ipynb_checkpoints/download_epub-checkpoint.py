import scrapy
import regex as re

class PoemSpider(scrapy.Spider):
    name = 'download_epub'
    start_urls = [f'https://old.shamela.ws/index.php/book/149482', 
                 'https://old.shamela.ws/index.php/book/8889',
                 'https://old.shamela.ws/index.php/book/4215']

    def parse(self, response):
        xpath_book_title = '//div[@id="content-div"]//h3/text()'
        xpath_author = '//div[@id="content-div"]//h3//a//text()'
        xpath_author_url = '//div[@id="content-div"]//h3//a//@href'
        
        book_title = response.xpath(xpath_book_title).getall()
        book_title = ' '.join(book_title).strip()
        
        
        author = response.xpath(xpath_author).getall()
        author = ' '.join(author).strip()
        
        author_url = response.xpath(xpath_author_url).getall()
        author_url = ' '.join(author_url).strip()
        
        book_url = response.url
        
        xpath_link = '//a[contains(@href, "epubs")]//@href'
        links = response.xpath(xpath_link).getall()
        link = links[0] if links else ""
        
        
        auth_suffix = f"{author_url}".strip().split('/')[-1]
        book_suffix = f"{book_url}".strip().split('/')[-1]
        file_name = book_title.strip()
        file_name = re.sub("\s+", '_', file_name)
        file_name = f'{file_name}_{auth_suffix}_{book_suffix}'
        



        yield {
            'BOOK_TITLE' : book_title,
            'AUTHOR' : author,
            'AUTHOR_URL' : author_url,
            'BOOK_URL' : book_url,
            'file_urls' : [link],
            'FILE_NAME' : file_name
        }
