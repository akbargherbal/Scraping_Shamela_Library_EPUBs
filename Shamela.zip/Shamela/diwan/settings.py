
BOT_NAME = 'diwan'

SPIDER_MODULES = ['diwan.spiders']
NEWSPIDER_MODULE = 'diwan.spiders'


# Obey robots.txt rules
ROBOTSTXT_OBEY = False


# DOWNLOAD_DELAY = 3.1

# Override the default request headers:
DEFAULT_REQUEST_HEADERS = {
'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.74 Safari/537.36'
}

ITEM_PIPELINES = {'diwan.pipelines.CustomFilePipelines': 1}
#ITEM_PIPELINES = {'scrapy.pipelines.files.FilesPipeline': 1}
FILES_STORE = 'downloaded_epub_files'


FEED_EXPORT_ENCODING = 'utf-8'